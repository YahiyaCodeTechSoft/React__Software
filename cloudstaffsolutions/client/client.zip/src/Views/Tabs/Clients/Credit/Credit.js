import React from 'react'

function Credit() {
  return (
    <div>Credit</div>
  )
}

export default Credit